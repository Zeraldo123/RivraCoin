Development moved to https://gitlab.com/blacknet-ninja

https://riva.org/ aims to continue on RIVA chain.
